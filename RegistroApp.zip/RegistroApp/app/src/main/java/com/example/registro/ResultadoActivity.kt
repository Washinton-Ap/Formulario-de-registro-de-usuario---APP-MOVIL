package com.example.registro

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class ResultadoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)

        // Mostrar datos recibidos
        findViewById<TextView>(R.id.tvResCedula).text   = intent.getStringExtra("CEDULA")   ?: "--"
        findViewById<TextView>(R.id.tvResNombres).text  = intent.getStringExtra("NOMBRES")  ?: "--"
        findViewById<TextView>(R.id.tvResFecha).text    = intent.getStringExtra("FECHA")    ?: "--"
        findViewById<TextView>(R.id.tvResCiudad).text   = intent.getStringExtra("CIUDAD")   ?: "--"
        findViewById<TextView>(R.id.tvResGenero).text   = intent.getStringExtra("GENERO")   ?: "--"
        findViewById<TextView>(R.id.tvResCorreo).text   = intent.getStringExtra("CORREO")   ?: "--"
        findViewById<TextView>(R.id.tvResTelefono).text = intent.getStringExtra("TELEFONO") ?: "--"

        // Botón volver
        findViewById<MaterialButton>(R.id.btnVolver).setOnClickListener { finish() }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
