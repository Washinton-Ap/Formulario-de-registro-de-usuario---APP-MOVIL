package com.example.registro

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    // TextInputLayouts
    private lateinit var tilCedula: TextInputLayout
    private lateinit var tilNombres: TextInputLayout
    private lateinit var tilFecha: TextInputLayout
    private lateinit var tilCiudad: TextInputLayout
    private lateinit var tilCorreo: TextInputLayout
    private lateinit var tilTelefono: TextInputLayout

    // EditTexts
    private lateinit var etCedula: TextInputEditText
    private lateinit var etNombres: TextInputEditText
    private lateinit var etFecha: TextInputEditText
    private lateinit var etCiudad: TextInputEditText
    private lateinit var etCorreo: TextInputEditText
    private lateinit var etTelefono: TextInputEditText

    // RadioGroup
    private lateinit var rgGenero: RadioGroup

    // Botones
    private lateinit var btnLimpiar: MaterialButton
    private lateinit var btnEnviar: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        inicializarVistas()
        configurarListeners()
    }

    private fun inicializarVistas() {
        tilCedula   = findViewById(R.id.tilCedula)
        tilNombres  = findViewById(R.id.tilNombres)
        tilFecha    = findViewById(R.id.tilFecha)
        tilCiudad   = findViewById(R.id.tilCiudad)
        tilCorreo   = findViewById(R.id.tilCorreo)
        tilTelefono = findViewById(R.id.tilTelefono)

        etCedula    = findViewById(R.id.etCedula)
        etNombres   = findViewById(R.id.etNombres)
        etFecha     = findViewById(R.id.etFecha)
        etCiudad    = findViewById(R.id.etCiudad)
        etCorreo    = findViewById(R.id.etCorreo)
        etTelefono  = findViewById(R.id.etTelefono)

        rgGenero    = findViewById(R.id.rgGenero)
        btnLimpiar  = findViewById(R.id.btnLimpiar)
        btnEnviar   = findViewById(R.id.btnEnviar)
    }

    private fun configurarListeners() {
        // DatePicker
        etFecha.setOnClickListener { mostrarDatePicker() }
        tilFecha.setEndIconOnClickListener { mostrarDatePicker() }

        // Mayúsculas automáticas en Nombres
        etNombres.addTextChangedListener(mayusculasWatcher(etNombres) { tilNombres.error = null })
        etCiudad.addTextChangedListener(mayusculasWatcher(etCiudad) { tilCiudad.error = null })

        // Limpiar errores al escribir
        etCedula.addTextChangedListener(limpiarErrorWatcher { tilCedula.error = null })
        etCorreo.addTextChangedListener(limpiarErrorWatcher { tilCorreo.error = null })
        etTelefono.addTextChangedListener(limpiarErrorWatcher { tilTelefono.error = null })

        btnLimpiar.setOnClickListener { limpiarFormulario() }
        btnEnviar.setOnClickListener  { if (validar()) enviar() }
    }

    private fun mayusculasWatcher(et: TextInputEditText, onChanged: () -> Unit) = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
            s?.let {
                onChanged()
                val upper = it.toString().uppercase()
                if (it.toString() != upper) {
                    et.removeTextChangedListener(this)
                    et.setText(upper)
                    et.setSelection(upper.length)
                    et.addTextChangedListener(this)
                }
            }
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    private fun limpiarErrorWatcher(onChanged: () -> Unit) = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) { onChanged() }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    private fun mostrarDatePicker() {
        val cal = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, y, m, d ->
                etFecha.setText(String.format("%02d/%02d/%04d", d, m + 1, y))
                tilFecha.error = null
            },
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)
        ).also {
            it.datePicker.maxDate = System.currentTimeMillis()
            it.show()
            it.getButton(DatePickerDialog.BUTTON_POSITIVE).setTextColor(getColor(R.color.naranja))
            it.getButton(DatePickerDialog.BUTTON_NEGATIVE).setTextColor(getColor(R.color.gris_texto))
        }
    }

    private fun validar(): Boolean {
        var ok = true

        val cedula = etCedula.text.toString().trim()
        when {
            cedula.isEmpty()              -> { tilCedula.error = "La cédula es requerida";           ok = false }
            cedula.length != 10           -> { tilCedula.error = "La cédula debe tener 10 dígitos";  ok = false }
            else                          -> tilCedula.error = null
        }

        val nombres = etNombres.text.toString().trim()
        if (nombres.isEmpty()) { tilNombres.error = "Los nombres son requeridos"; ok = false }
        else tilNombres.error = null

        val fecha = etFecha.text.toString().trim()
        if (fecha.isEmpty()) { tilFecha.error = "Seleccione la fecha de nacimiento"; ok = false }
        else tilFecha.error = null

        val ciudad = etCiudad.text.toString().trim()
        if (ciudad.isEmpty()) { tilCiudad.error = "La ciudad es requerida"; ok = false }
        else tilCiudad.error = null

        if (rgGenero.checkedRadioButtonId == -1) {
            Toast.makeText(this, "Seleccione un género", Toast.LENGTH_SHORT).show()
            ok = false
        }

        val correo = etCorreo.text.toString().trim()
        when {
            correo.isEmpty()                                         -> { tilCorreo.error = "El correo es requerido";        ok = false }
            !Patterns.EMAIL_ADDRESS.matcher(correo).matches()       -> { tilCorreo.error = "Ingrese un correo válido";      ok = false }
            else                                                     -> tilCorreo.error = null
        }

        val tel = etTelefono.text.toString().trim()
        when {
            tel.isEmpty()           -> { tilTelefono.error = "El teléfono es requerido";          ok = false }
            tel.length < 10        -> { tilTelefono.error = "Ingrese un número válido (10 dígitos)"; ok = false }
            else                   -> tilTelefono.error = null
        }

        return ok
    }

    private fun generoSeleccionado() = when (rgGenero.checkedRadioButtonId) {
        R.id.rbHombre -> "Hombre"
        R.id.rbMujer  -> "Mujer"
        else           -> ""
    }

    private fun enviar() {
        startActivity(Intent(this, ResultadoActivity::class.java).apply {
            putExtra("CEDULA",   etCedula.text.toString().trim())
            putExtra("NOMBRES",  etNombres.text.toString().trim())
            putExtra("FECHA",    etFecha.text.toString().trim())
            putExtra("CIUDAD",   etCiudad.text.toString().trim())
            putExtra("GENERO",   generoSeleccionado())
            putExtra("CORREO",   etCorreo.text.toString().trim())
            putExtra("TELEFONO", etTelefono.text.toString().trim())
        })
    }

    private fun limpiarFormulario() {
        listOf(etCedula, etNombres, etFecha, etCiudad, etCorreo, etTelefono).forEach { it.setText("") }
        listOf(tilCedula, tilNombres, tilFecha, tilCiudad, tilCorreo, tilTelefono).forEach { it.error = null }
        rgGenero.clearCheck()
        etCedula.requestFocus()
        Toast.makeText(this, "Formulario limpiado", Toast.LENGTH_SHORT).show()
    }
}
