package com.example.registro
import org.junit.Test
import org.junit.Assert.*
class ExampleUnitTest {
    @Test fun addition_isCorrect() { assertEquals(4, 2 + 2) }
}
